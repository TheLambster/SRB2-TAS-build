#ifndef __MAC_RESOURCES_H__
#define __MAC_RESOURCES_H__

void OSX_GetResourcesPath(char * buffer);
#endif